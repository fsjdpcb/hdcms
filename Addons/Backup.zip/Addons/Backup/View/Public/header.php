<?php if (!defined('HDPHP_PATH')) exit(); ?>
<!doctype html>
<html lang="en">
<head>
<head>
    <meta charset="UTF-8">
    <title>系统后台 - {$hd.config.webname} - by HDCMS</title>
    <hdjs/>
    <css file="__PUBLIC__/common.css"/>
</head>